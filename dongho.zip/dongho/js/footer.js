function footer(){
    return "<div class=\"bg-footer-up\">\n" +
        "            <div class=\"container\">\n" +
        "                <div class=\"col-md-12 footer-up\">\n" +
        "                    <div class=\"col-md-3 pull-left tro-giup\">\n" +
        "                        <p><b><i>TRỢ GIÚP KHÁCH HÀNG</i></b></p>\n" +
        "                        <ul class=\"list-unstyled\">\n" +
        "                            <li>\n" +
        "                                <a href=\"#\">CHÍNH SÁCH BÁN HÀNG</a>\n" +
        "                            </li>\n" +
        "                            <li>\n" +
        "                                <a href=\"#\">BẢO HÀNH VÀ SỬA CHỮA</a>\n" +
        "                            </li>\n" +
        "                            <li>\n" +
        "                                <a href=\"#\">CHÍNH SÁCH BẢO MẬT</a>\n" +
        "                            </li>\n" +
        "                            <li>\n" +
        "                                <a href=\"#\">VỀ CHÚNG TÔI</a>\n" +
        "                            </li>\n" +
        "                            <li>\n" +
        "                                <a href=\"#\">CHÍNH SÁCH COOKIE</a>\n" +
        "                            </li>\n" +
        "\n" +
        "                        </ul>\n" +
        "                    </div>\n" +
        "                    <div class=\"col-md-3 pull-left lien-ket\">\n" +
        "                        <p><b><i>LIÊN KẾT WEBSITE</i></b></p>\n" +
        "                        <ul class=\"list-unstyled\">\n" +
        "                            <li>\n" +
        "                                <a href=\"#\">THƯƠNG HIỆU</a>\n" +
        "                            </li>\n" +
        "                            <li>\n" +
        "                                <a href=\"#\">ĐỒNG HỒ NAM</a>\n" +
        "                            </li>\n" +
        "                            <li>\n" +
        "                                <a href=\"#\">ĐỒNG HỒ NỮ</a>\n" +
        "                            </li>\n" +
        "                            <li>\n" +
        "                                <a href=\"#\">SỰ KIỆN</a>\n" +
        "                            </li>\n" +
        "                            <li>\n" +
        "                                <a href=\"#\">WATCH SET</a>\n" +
        "                            </li>\n" +
        "\n" +
        "                        </ul>\n" +
        "                    </div>\n" +
        "                    <div class=\"col-md-3 pull-left face-book\">\n" +
        "                        <p><b><i>CHÚNG TÔI TRÊN FACEBOOK</i></b></p>\n" +
        "                        <div class=\"fb-page\" data-href=\"https://www.facebook.com/&#x110;&#x1ed3;ng-h&#x1ed3;-cao-c&#x1ea5;p-106158437959435\" data-tabs=\"timeline\" data-width=\"\" data-height=\"100\" data-small-header=\"true\" data-adapt-container-width=\"true\" data-hide-cover=\"false\" data-show-facepile=\"false\"><blockquote cite=\"https://www.facebook.com/&#x110;&#x1ed3;ng-h&#x1ed3;-cao-c&#x1ea5;p-106158437959435\" class=\"fb-xfbml-parse-ignore\"><a href=\"https://www.facebook.com/&#x110;&#x1ed3;ng-h&#x1ed3;-cao-c&#x1ea5;p-106158437959435\">Đồng hồ cao cấp</a></blockquote></div>\n" +
        "\n" +
        "                    </div>\n" +
        "                    <div class=\"col-md-3 pull-right ket-noi\">\n" +
        "                        <p class=\"pull-right\"><b><i>KẾT NỐI VỚI CHÚNG TÔI</i></b></p>\n" +
        "                        <div class=\"pull-right social-icon\">\n" +
        "                            <a href=\"https://www.facebook.com/\" target=\"blank\" class=\"fab fa-facebook-square col-md-4\"></a>\n" +
        "                            <a href=\"https://www.youtube.com/\" target=\"blank\" class=\"fab fa-youtube-square col-md-4\"></a>\n" +
        "                            <a href=\"https://www.twitter.com/\" target=\"blank\" class=\"fab fa-twitter-square col-md-4\"></a>\n" +
        "\n" +
        "                        </div>\n" +
        "\n" +
        "                    </div>\n" +
        "                </div>\n" +
        "\n" +
        "\n" +
        "\n" +
        "            </div>\n" +
        "\n" +
        "        </div>\n" +
        "        <div class=\"bg-footer-down\">\n" +
        "            <div class=\"container\">\n" +
        "                <div class=\"col-md-12 footer-down\">\n" +
        "                    <p>CÔNG TY CỔ PHẦN XNK HÀNG HIỆU HOA KỲ\n" +
        "                    </p>\n" +
        "                    <p>\n" +
        "                        Địa chỉ: 331 Nguyễn Đình Chiểu, Phường 5, Quận 3, TP. HCM - Điện thoại: 028 3833 9999 | 024 77776677 | 028 77776677 - MST: 0312756049\n" +
        "                    </p>\n" +
        "                </div>\n" +
        "\n" +
        "            </div>\n" +
        "        </div>"
}
var footer1= document.getElementById("footer");
footer1.innerHTML = footer();