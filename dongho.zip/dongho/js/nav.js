function nav(){
    return "<div class=\"container\">\n" +
        "            <div class=\"row col md-3 col-md-offset-5 logo\">\n" +
        "                <img src=\"imgs/logo-luxury.png\" height=\"150\" width=\"160\"/>\n" +
        "            </div>\n" +
        "            <div class=\"row col-md-12 menu\">\n" +
        "                <div class=\"a-menu pull-left\">\n" +
        "                    <label>\n" +
        "                        <a href=\"#\">\n" +
        "                            <p>\n" +
        "                                THƯƠNG HIỆU\n" +
        "                            </p>\n" +
        "                        </a>\n" +
        "                    </label>\n" +
        "                </div>\n" +
        "                <div class=\"a-menu col-md-2 pull-left\">\n" +
        "                    <label>\n" +
        "                        <a href=\"#\">\n" +
        "                            <p>\n" +
        "                                ĐỒNG HỒ NAM\n" +
        "                            </p>\n" +
        "                        </a>\n" +
        "                    </label>\n" +
        "                </div>\n" +
        "                <div class=\"a-menu pull-left\">\n" +
        "                    <label>\n" +
        "                        <a href=\"#\">\n" +
        "                            <p>\n" +
        "                                ĐỒNG HỒ NỮ\n" +
        "                            </p>\n" +
        "                        </a>\n" +
        "                    </label>\n" +
        "                </div>\n" +
        "                <div class=\"col-md-2 a-menu pull-left\">\n" +
        "                    <label>\n" +
        "                        <a href=\"#\">\n" +
        "                            <p>\n" +
        "                                ĐỒNG HỒ CẶP ĐÔI\n" +
        "                            </p>\n" +
        "                        </a>\n" +
        "                    </label>\n" +
        "                </div>\n" +
        "                <div class=\"col-md-2 a-menu pull-left\">\n" +
        "                    <label>\n" +
        "                        <a href=\"#\">\n" +
        "                            <p>\n" +
        "                                SẢN PHẨM HOT\n" +
        "                            </p>\n" +
        "                        </a>\n" +
        "                    </label>\n" +
        "                </div>\n" +
        "                <div class=\"col-md-1 a-menu pull-left\">\n" +
        "                    <label>\n" +
        "                        <a href=\"#\">\n" +
        "                            <p>\n" +
        "                                SALE\n" +
        "                            </p>\n" +
        "                        </a>\n" +
        "                    </label>\n" +
        "                </div>\n" +
        "                <div class=\"col-md-2 a-menu pull-left\">\n" +
        "                    <label>\n" +
        "                        <a href=\"#\">\n" +
        "                            <p>\n" +
        "                                SPECIAL EVENT\n" +
        "                            </p>\n" +
        "                        </a>\n" +
        "                    </label>\n" +
        "                </div>\n" +
        "\n" +
        "\n" +
        "            </div>\n" +
        "\n" +
        "        </div>"
}
var nav1 = document.getElementById("nav");
nav1.innerHTML = nav();
